﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz3
{
    class Demo
    {
        int x;
        static void Main(string[] args)
        {
            byte b = 125;
            b += 131;
            Console.WriteLine(b);
        }
    }
}
