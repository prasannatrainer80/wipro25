﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbsCon
{
    class Amrut : Employ
    {
        public Amrut(int empno, string name, double basic) : base(empno, name, basic)
        {

        }
    }
}
