exports.greets = function() {
    return "Greeting from Node Js Platform...";
}