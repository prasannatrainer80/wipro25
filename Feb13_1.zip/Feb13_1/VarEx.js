exports.show = function(firstName, lastName) {
    return firstName + " " +lastName;
}