exports.hello = function() {
    return "Welcome to Node Js Custom Module...";
}