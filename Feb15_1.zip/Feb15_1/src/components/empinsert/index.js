import empinsert from "./empinsert"
export default empinsert;
