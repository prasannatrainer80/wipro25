import logo from './logo.svg';
import './App.css';
import NameReducer from './NameReducer';
import ButtonEx from './ButtonEx';

function App() {
  return (
    <div className="App">
     <ButtonEx /> 
     
    </div>
  );
}

export default App;
