import logo from './logo.svg';
import './App.css';
import Result from './Result';

function App() {
  return (
    <div className="App">
      <Result />
    </div>
  );
}

export default App;
