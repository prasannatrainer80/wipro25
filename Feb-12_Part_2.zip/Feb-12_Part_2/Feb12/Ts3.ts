let counter : number;
// counter = "Welcome";
let names : string[] =
[
    "Raj","Keshav","Sudipta","Palak",
    "Ranvir"
]

names.forEach(x => console.log(x));