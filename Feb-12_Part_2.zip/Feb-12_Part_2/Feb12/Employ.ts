export class Employ {
    constructor(public empno : number, public name : string, 

        public salary : number 
    )
    {

    }
}