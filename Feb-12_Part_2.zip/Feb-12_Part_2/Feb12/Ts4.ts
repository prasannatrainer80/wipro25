let employ : {
    empno : number;
    name : string;
    salary : number;
}

employ = {
    empno :1,
    name : "Raj",
    salary : 88323
}

console.log(employ.empno);
console.log(employ.name);
console.log(employ.salary);