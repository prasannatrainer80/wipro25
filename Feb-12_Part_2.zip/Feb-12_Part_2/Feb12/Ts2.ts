let studentName : string = "Keshav"
let age : number = 22 
let isActive : boolean = true

console.log("Student Name " +studentName);
console.log("Age  " +age);
console.log("Status  " +isActive);