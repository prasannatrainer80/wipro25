var show = function (eno, name, company) {
    if (company === void 0) { company = "Wipro"; }
    console.log(eno + " " + name + " " + company);
};
show(1, "Prasanna", "Deloitte");
show(2, "Kalyan");
