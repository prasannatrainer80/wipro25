var e1 = { empno: 1, nam: "Raj", salary: 82822 };
console.log(e1.empno);
console.log(e1.nam);
console.log(e1.salary);
var e2 = "Prasanna";
console.log(e2);
var e3 = 82344;
console.log(e3);
