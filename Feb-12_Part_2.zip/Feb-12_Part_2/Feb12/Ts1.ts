console.log("Welcome to Typescript");
let company : string = "Wipro";
let para = document.createElement("p");
para.textContent = company;
document.body.appendChild(para);