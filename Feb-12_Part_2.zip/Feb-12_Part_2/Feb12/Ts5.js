var sayHello = function () {
    return "Welcome to TypeScript...";
};
console.log(sayHello());
