export class Test {

    sum = (a:number, b:number) => {return a+b};
    sub = (a:number,b : number) => {return a-b};
    mult = (a:number,b:number) => {return a * b};
}