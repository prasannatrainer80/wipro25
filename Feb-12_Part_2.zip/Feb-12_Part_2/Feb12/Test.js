"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Test = void 0;
var Test = /** @class */ (function () {
    function Test() {
        this.sum = function (a, b) { return a + b; };
        this.sub = function (a, b) { return a - b; };
        this.mult = function (a, b) { return a * b; };
    }
    return Test;
}());
exports.Test = Test;
