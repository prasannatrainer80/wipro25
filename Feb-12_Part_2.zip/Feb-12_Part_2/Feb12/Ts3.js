var counter;
// counter = "Welcome";
var names = [
    "Raj", "Keshav", "Sudipta", "Palak",
    "Ranvir"
];
names.forEach(function (x) { return console.log(x); });
