"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Employ = void 0;
var Employ = /** @class */ (function () {
    function Employ(empno, name, salary) {
        this.empno = empno;
        this.name = name;
        this.salary = salary;
    }
    return Employ;
}());
exports.Employ = Employ;
