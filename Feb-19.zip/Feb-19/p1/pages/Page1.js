export default function Page1() {
    return(
        <div>
            Welcome to Page1...
        </div>
    )
}