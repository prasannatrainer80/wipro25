export default function Page2() {
    return(
        <div>
            Welcome to Page2...
        </div>
    )
}