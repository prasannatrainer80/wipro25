export default function Page3() {
    return(
        <div>
            Welcome to Page3...
        </div>
    )
}