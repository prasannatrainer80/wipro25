import nameex from "./nameex"
export default nameex;
