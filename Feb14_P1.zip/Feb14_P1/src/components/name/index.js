import name from "./name"
export default name;
