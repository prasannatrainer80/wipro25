import React, { Component } from "react";

const Fc1 = () => {
    return(
        <div>
            <p>Welcome to Functional Components</p>
            <p>From Wipro</p>
        </div>
    )
}

export default Fc1;