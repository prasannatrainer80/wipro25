-- String Functions

-- Number Funtions

-- Date Functions

-- Aggregate Functions

-- Group By 

-- ABS() : Returns the absolute value 

select abs(-12) 
GO

-- sqrt(n) : Returns the sqrt value 

select sqrt(49)
GO

-- power(n,m) : Returns n power m value 

select power(2,3) 
GO

-- ceiling() : Returns the greatest integer value 

select CEILING(12.0000001) 
GO

-- Floor() : Returns the smallest integer value 

select floor(12.99999)
GO
